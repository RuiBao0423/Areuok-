"""UNet++ (Zhou et al., 2018) with nested dense skip pathways.

The implementation is intentionally dependency-free beyond PyTorch and supports
the paper's deep-supervision heads. Inputs can be one-channel BUSI ultrasound.
"""
import torch
from torch import nn
import torch.nn.functional as F


class ConvBlock(nn.Module):
    def __init__(self, in_channels, out_channels):
        super().__init__()
        self.block = nn.Sequential(
            nn.Conv2d(in_channels, out_channels, 3, padding=1, bias=False),
            nn.BatchNorm2d(out_channels), nn.ReLU(inplace=True),
            nn.Conv2d(out_channels, out_channels, 3, padding=1, bias=False),
            nn.BatchNorm2d(out_channels), nn.ReLU(inplace=True),
        )

    def forward(self, x):
        return self.block(x)


class UNetPlusPlus(nn.Module):
    """Four-level UNet++.

    During training, ``deep_supervision=True`` returns four full-resolution
    logits (x0,1 ... x0,4). In evaluation it returns their mean, matching the
    ensemble-style inference described in the original paper.
    """
    def __init__(self, in_channels=1, num_classes=1,
                 filters=(32, 64, 128, 256, 512), deep_supervision=True):
        super().__init__()
        if len(filters) != 5:
            raise ValueError("filters must contain five channel widths")
        self.deep_supervision = deep_supervision
        self.pool = nn.MaxPool2d(2)
        self.nodes = nn.ModuleDict()
        for i, out_ch in enumerate(filters):
            self.nodes[f"{i}_0"] = ConvBlock(in_channels if i == 0 else filters[i-1], out_ch)
        # X^{i,j} receives j earlier nodes at level i plus upsampled X^{i+1,j-1}.
        for j in range(1, 5):
            for i in range(5 - j):
                self.nodes[f"{i}_{j}"] = ConvBlock(filters[i] * j + filters[i+1], filters[i])
        self.heads = nn.ModuleList([nn.Conv2d(filters[0], num_classes, 1) for _ in range(4)])

    @staticmethod
    def _up_to(x, ref):
        return F.interpolate(x, size=ref.shape[-2:], mode="bilinear", align_corners=False)

    def forward(self, x):
        grid = {}
        grid[0, 0] = self.nodes["0_0"](x)
        for i in range(1, 5):
            grid[i, 0] = self.nodes[f"{i}_0"](self.pool(grid[i-1, 0]))
        for j in range(1, 5):
            for i in range(5 - j):
                parts = [grid[i, k] for k in range(j)]
                parts.append(self._up_to(grid[i+1, j-1], grid[i, 0]))
                grid[i, j] = self.nodes[f"{i}_{j}"](torch.cat(parts, dim=1))
        logits = [head(grid[0, j]) for j, head in enumerate(self.heads, start=1)]
        if self.training and self.deep_supervision:
            return logits
        return torch.stack(logits).mean(0) if self.deep_supervision else logits[-1]

