"""Train/evaluate UNet++ on the EDA-cleaned BUSI split."""
import argparse
import glob
import json
import os
import sys
import time
import numpy as np
import torch
from torch import nn
from torch.utils.data import DataLoader

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from common.data import DATA_DIR, SegDataset, make_split
from common.metrics import aggregate_seg
from common.runner import DEVICE, RESULTS_DIR, plot_curve, save_results, save_seg_examples, set_seed
from models.unetpp.model import UNetPlusPlus


def soft_dice_loss(logits, target, eps=1e-6):
    prob = torch.sigmoid(logits)
    dims = (1, 2, 3)
    inter = (prob * target).sum(dims)
    score = (2 * inter + eps) / (prob.sum(dims) + target.sum(dims) + eps)
    return 1 - score.mean()


def loss_for(output, target, bce):
    outputs = output if isinstance(output, (list, tuple)) else [output]
    return torch.stack([bce(x, target) + soft_dice_loss(x, target) for x in outputs]).mean()


@torch.no_grad()
def validate(model, loader, bce):
    model.eval(); losses, dices = [], []
    for x, y in loader:
        x, y = x.to(DEVICE), y.to(DEVICE)
        logits = model(x)
        losses.append(float(loss_for(logits, y, bce)))
        pred = torch.sigmoid(logits) >= .5
        inter = (pred * y.bool()).sum((1, 2, 3)).float()
        den = pred.sum((1, 2, 3)).float() + y.sum((1, 2, 3))
        dices.extend(((2 * inter + 1e-6) / (den + 1e-6)).cpu().tolist())
    return float(np.mean(losses)), float(np.mean(dices))


def train(args):
    set_seed(args.seed)
    if not os.path.isdir(DATA_DIR):
        raise FileNotFoundError(
            f"BUSI dataset not found at {DATA_DIR}. See README_UNETPP.md for the required layout.")
    images = [p for p in glob.glob(os.path.join(DATA_DIR, "*", "*.png"))
              if "_mask" not in os.path.basename(p)]
    if not images:
        raise FileNotFoundError(
            "BUSI dataset directory exists but contains no source PNG images. "
            f"Extract the benign, malignant and normal folders into: {DATA_DIR}")
    df = make_split(seed=args.seed)
    train_ds = SegDataset(df, "train", augment=not args.no_augment)
    val_ds = SegDataset(df, "val")
    test_ds = SegDataset(df, "test")
    loaders = {
        "train": DataLoader(train_ds, args.batch_size, shuffle=True, num_workers=args.workers,
                            pin_memory=DEVICE.type == "cuda"),
        "val": DataLoader(val_ds, args.batch_size, num_workers=args.workers),
        "test": DataLoader(test_ds, args.batch_size, num_workers=args.workers),
    }
    filters = tuple(int(v) for v in args.filters.split(","))
    model = UNetPlusPlus(filters=filters, deep_supervision=not args.no_deep_supervision).to(DEVICE)
    bce = nn.BCEWithLogitsLoss()
    opt = torch.optim.Adam(model.parameters(), lr=args.lr, weight_decay=args.weight_decay)
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(opt, mode="max", patience=5, factor=.5)
    os.makedirs(RESULTS_DIR, exist_ok=True)
    checkpoint = os.path.join(RESULTS_DIR, "unetpp_best.pt")
    history = {"train_loss": [], "val_loss": [], "val_dice": []}
    best, stale, started = -1., 0, time.time()
    for epoch in range(1, args.epochs + 1):
        model.train(); running = []
        for x, y in loaders["train"]:
            x, y = x.to(DEVICE), y.to(DEVICE)
            opt.zero_grad(set_to_none=True)
            loss = loss_for(model(x), y, bce)
            loss.backward(); opt.step(); running.append(float(loss.detach()))
        va_loss, va_dice = validate(model, loaders["val"], bce)
        tr_loss = float(np.mean(running))
        for key, value in (("train_loss", tr_loss), ("val_loss", va_loss), ("val_dice", va_dice)):
            history[key].append(value)
        scheduler.step(va_dice)
        print(f"epoch {epoch:03d} train_loss={tr_loss:.4f} val_loss={va_loss:.4f} val_dice={va_dice:.4f}")
        if va_dice > best:
            best, stale = va_dice, 0
            torch.save({"model": model.state_dict(), "filters": filters, "epoch": epoch,
                        "val_dice": best, "args": vars(args)}, checkpoint)
        else:
            stale += 1
            if stale >= args.patience:
                print(f"early stopping after {epoch} epochs"); break

    state = torch.load(checkpoint, map_location=DEVICE, weights_only=False)
    model.load_state_dict(state["model"]); model.eval()
    preds, gts, examples = [], [], []
    with torch.no_grad():
        for x, y in loaders["test"]:
            logits = model(x.to(DEVICE)); p = (torch.sigmoid(logits) >= args.threshold).cpu().numpy()
            for image, gt, pred in zip(x.numpy(), y.numpy(), p):
                preds.append(pred[0]); gts.append(gt[0]); examples.append((image[0], gt[0], pred[0]))
    result = {"paper": "Zhou et al. (2018), UNet++", "device": str(DEVICE),
              "best_epoch": state["epoch"], "best_val_dice": state["val_dice"],
              "threshold": args.threshold, "test": aggregate_seg(preds, gts),
              "history": history, "seconds": round(time.time() - started, 1), "config": vars(args)}
    save_results("unetpp", result); plot_curve(history, "unetpp", ("train_loss", "val_dice"))
    save_seg_examples(examples, "unetpp")
    print(json.dumps(result["test"], indent=2)); return result


def parse_args():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--epochs", type=int, default=100); p.add_argument("--batch-size", type=int, default=8)
    p.add_argument("--lr", type=float, default=1e-3); p.add_argument("--weight-decay", type=float, default=1e-5)
    p.add_argument("--patience", type=int, default=15); p.add_argument("--threshold", type=float, default=.5)
    p.add_argument("--filters", default="32,64,128,256,512"); p.add_argument("--workers", type=int, default=0)
    p.add_argument("--seed", type=int, default=42); p.add_argument("--no-augment", action="store_true")
    p.add_argument("--no-deep-supervision", action="store_true"); return p.parse_args()


if __name__ == "__main__":
    train(parse_args())
